package de.nomoruyi.blue_tine_interpreted_components

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
